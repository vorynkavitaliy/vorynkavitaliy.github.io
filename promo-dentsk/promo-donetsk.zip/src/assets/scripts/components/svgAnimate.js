// import KUTE from 'kute.js'

// const headerPage = KUTE.to('#header-page', { text: 'Донецксталь' })
// const subHeaderPage = KUTE.to(
//     '#subheader-page',
//     {
//         text:
//             'Внутренний чат-бот компании <strong class="text text-head-s black-g uppercase">ДОНЕЦКСТАЛЬ</strong>',
//     },
//     { duration: 3000 }
// )

// document.addEventListener('DOMContentLoaded', () => {
//     headerPage.start()
//     subHeaderPage.start()
// })
