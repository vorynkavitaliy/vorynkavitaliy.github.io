import './components/setIcons'
import './components/button'
import './components/svgAnimate'
